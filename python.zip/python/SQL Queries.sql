create database details;

create table company0
(ID int,
Name varchar(50),
Age int,
Department varchar(50),
Salary int,
)

create table children
(ID int,
Family_members int,
)

insert into children values(101, 3),
(102, 2),
(103, 4),
(104, 5),
(105, 6);


insert into company0 values(101, 'Dharmesh', 31, 'IT', 63500),
(102, 'Sanah', 21, 'Finance', 23500),
(103, 'Dharam', 20, 'IT', 19000),
(104, 'Sam', 30, 'Sales', 60000),
(105, 'Viraj', 21, 'Accounts', 18500);
 

-- SELECT QUERY (Used to execute the entire data)
select * from children

select * from company0

-- SELECT Query(Particular column/row)
SELECT Name from company0
WHERE Age = 30;

--DROP TABLES
Drop table company0;
Drop table children;

-- DROP DATABASE(Will delete the entire information present in the database)
Drop Database details

--TRUNCATE(Deletes the DATA from the Table)
TRUNCATE TABLE children;

--INSERT QUERY
Insert into company0 values(106, 'RutuJa',32, 'Accounts', '52000');

--CHANGE Query
// change column
sp_rename 'children.Family_members', 'family_members';

// change table name
sp_rename 'children', 'School';

// change db name
sp_renamedb 'details' , 'Details'


--Update Query
UPDATE company0
SET NAME = 'Viaan'
WHERE ID = 105;

-- ASCENDING AND DESCENDING ORDER BY
select * from children order by Family_members ASC

select * from children order by Family_members DESC


--JOINS
select company0.Salary, children.Family_members
From company0
inner join children
on company0.ID=children.ID; 


select children.Family_members, company0.ID, company0.Name, company0.Department, company0.Salary
from company0
left join children
on company0.ID= children.ID


select company0.ID, company0.Name, company0.Department, company0.Salary,children.Family_members
from company0
right join children
on company0.ID= children.ID


select company0.ID, company0.Name, company0.Department, company0.Salary,children.Family_members
from company0
full outer join children
on company0.ID= children.ID

--UNION JOIN
SELECT ID FROM company0
UNION
SELECT ID FROM children;

--UNION ALL 
SELECT ID FROM children
UNION ALL
SELECT ID FROM company0
ORDER BY ID;


-- Average Function

select ID, Name, Age, Department, Salary,
AVG(Salary) over (Partition by Department) as Avg_Salary
from company0

select ID, Name, Age, Department, Salary,
AVG(Salary) over (Partition by Age order by Department) as Avg_Salary
from company0


--RANKING WINDOW FUNCTION
Select
Row_number() over (Partition by Department order by Age) as sr_number,ID,Name,Age,Department,Salary,
Rank() over (Partition by Department order by Age) as sr_rank, 
Dense_rank() over (Partition by Department order by Age) as sr_denserank
from company0

--group by in ascending order 
select Age, Max(Salary) as Max_Salary from company0 Group by Age;

--having clause
Select Department,Age, Min(Salary) as Min_sal from company0 Group by Department,Age, Salary Having Salary >20000;

--Ntile, Lag, Lead

Select ID, ntile (2) over (order by ID) as Comp_id from company0 

select  ID , Lag(Age,1,26) over (order by Age ASC) as Age_list from company0 

Select Name, LEAD(Age,2, 29) over (order by Age Desc) as Age_List from company0


--LIMIT FUNCTION/ Top 
Select Top 3 * From children ;


--Query for UPPER, LOWER, COUNT, LEN, SUBSTRING, TRIM, GETDATE, FORMAT, CONCAT

Select UPPER (Department) from company0;

Select LOWER(Name) from company0;

Select COUNT(Name) from company0;

Select LEN(Name) from company0;

Select SUBSTRING(Name,1,3) from company0;

Select TRIM(Salary) from company0;

Select GETDATE();

Select FORMAT(26072023, '##-##-####') ;

Select CONCAT(Name, Age) from company0;

select CURRENT_TIMESTAMP;


--Aliases functions / OTHER AGGREGATE FUNCTIONS

SELECT MIN(Age) AS smallest from company0;
SELECT MAX(Age) AS biggest from company0;
SELECT AVG(ID) AS Average from company0;
SELECT SUM(ID) AS total from company0;


-- AGGREGATE FUNCTIONS with OVER/PARTITION BY
SELECT ID, Name, Age, Department,
Sum(ID) OVER( PARTITION BY Name) AS "Total", 
Avg(Age) OVER( PARTITION BY Department) AS "Average", 
Count(ID) OVER( PARTITION BY Department) AS "Count", 
Min(ID) OVER( PARTITION BY Name) AS "Min", 
Max(ID) OVER( PARTITION BY Name) AS "Max"
FROM company0;


-- TIMESTAMP FUNCTION
create table time_stamp1(
ID int,
NAME varchar(50),
Timestamp Datetime Default Getdate()
);

insert into time_stamp1 (ID, NAME) values (100, 'RAGHAV');

select * from time_stamp1
Drop table time_stamp1



 -- CTE(Common Table Expression for one column) 
With my_cte AS (
Select Salary from company0
)
Select Min(Salary) AS min_salary, Max(Salary) AS max_salary, Avg(Salary) AS avg_salary
From my_cte;

-- CTE(Common Table Expression using inner join and left join)
With My_Cte AS(
Select  Name, Family_members from company0 INNER JOIN children
ON company0.ID= children.ID
)
Select  Name, Family_members
From My_Cte;

With CTE AS (
Select Family_members,Age,Name
From company0
LEFT JOIN children
ON company0.ID= children.ID
)
Select Family_members,Age,Name
From CTE




